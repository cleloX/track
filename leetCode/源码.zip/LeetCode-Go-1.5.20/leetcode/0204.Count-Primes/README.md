# [204. Count Primes](https://leetcode.com/problems/count-primes/)


## 题目

Count the number of prime numbers less than a non-negative number, **n**.

**Example:**

    Input: 10
    Output: 4
    Explanation: There are 4 prime numbers less than 10, they are 2, 3, 5, 7.


## 题目大意

统计所有小于非负整数 n 的质数的数量。


## 解题思路

- 给出一个数字 n，要求输出小于 n 的所有素数的个数总和。简单题。
